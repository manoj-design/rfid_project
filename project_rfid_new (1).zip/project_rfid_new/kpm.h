//kpm.h
#include "types.h"
void Initkpm(void);
u32  ColScan(void);
u32  RowCheck(void);
u32  ColCheck(void);
u32  KeyScan(void);
