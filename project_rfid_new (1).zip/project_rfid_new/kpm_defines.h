#define ROW0 16 //p1.16
#define ROW1 17 //p1.17
#define ROW2 18 //p1.18
#define ROW3 19 //p1.19
#define COL0 20 //p1.20
#define COL1 21 //p1.21
#define COL2 22 //p1.22
#define COL3 23 //p1.23
void Initkpm(void);
u32 colscan(void);
u32 rowcheck(void);
u32 colcheck(void);
u32 keyscan(void);

